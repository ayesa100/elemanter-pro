<?php

namespace AmeliaBooking\Application\Commands\Bookable\Package;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class UpdatePackagesPositionsCommand
 *
 * @package AmeliaBooking\Application\Commands\Bookable\Package
 */
class UpdatePackagesPositionsCommand extends Command
{

}
