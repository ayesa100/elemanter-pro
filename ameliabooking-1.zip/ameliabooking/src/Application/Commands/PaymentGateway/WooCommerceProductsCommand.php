<?php

namespace AmeliaBooking\Application\Commands\PaymentGateway;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class WooCommerceProductsCommand
 *
 * @package AmeliaBooking\Application\Commands\PaymentGateway
 */
class WooCommerceProductsCommand extends Command
{

}
