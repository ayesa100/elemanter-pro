<?php

namespace AmeliaBooking\Application\Commands\Notification;

use AmeliaBooking\Application\Commands\Command;

/**
 * Class AddNotificationCommand
 *
 * @package AmeliaBooking\Application\Commands\Notification
 */
class AddNotificationCommand extends Command
{

}
