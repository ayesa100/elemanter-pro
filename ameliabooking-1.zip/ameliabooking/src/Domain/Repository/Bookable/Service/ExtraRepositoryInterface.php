<?php

namespace AmeliaBooking\Domain\Repository\Bookable\Service;

use AmeliaBooking\Domain\Repository\BaseRepositoryInterface;

/**
 * Interface ExtraRepositoryInterface
 *
 * @package AmeliaBooking\Domain\Repository\Bookable\Service
 */
interface ExtraRepositoryInterface extends BaseRepositoryInterface
{
}
