<?php

namespace ElementorPro\Base\MarkerInterfaces;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

interface Template_With_Post_Content_Interface {
}
