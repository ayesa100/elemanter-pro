<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/remote-location" only-nested=true }}
"TELECOMMUTE"
